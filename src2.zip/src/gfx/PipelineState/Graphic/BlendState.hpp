#include VG_GFXAPI_IMPL(BlendState)

namespace vg::gfx
{
    VG_STATIC_ASSERT(sizeof(RenderTargetBlend) == 4, "Invalid sizeof(RenderTargetBlend)");
}