#pragma once

namespace vg::gfx
{
    constexpr core::uint maxRenderTarget = 8;
}