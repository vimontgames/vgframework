#include VG_GFXAPI_IMPL(RasterizerState)
