#pragma once

#include "gfx/IImporter.h"

namespace vg::gfx
{
    class Importer : public IImporter
    {
    public:

    private:
  
    };
}