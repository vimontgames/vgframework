#pragma once

#include "gfx/FrameGraph/SubPass.h"

namespace vg::gfx::vulkan
{
	//--------------------------------------------------------------------------------------
	SubPass::SubPass():
        super::SubPass()
	{

	}

	//--------------------------------------------------------------------------------------
	SubPass::~SubPass()
	{

	}
}