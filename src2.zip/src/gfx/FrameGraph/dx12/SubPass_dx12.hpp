#pragma once

#include "gfx/FrameGraph/SubPass.h"

namespace vg::gfx::dx12
{
	//--------------------------------------------------------------------------------------
	SubPass::SubPass() :
        super::SubPass()
	{

	}

	//--------------------------------------------------------------------------------------
	SubPass::~SubPass()
	{

	}
}