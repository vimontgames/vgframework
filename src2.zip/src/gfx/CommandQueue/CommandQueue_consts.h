#pragma once

#include "gfx/CommandList/CommandList_consts.h"

namespace vg::gfx
{
	using CommandQueueType = CommandListType;
}