#pragma once

namespace vg::gfx
{
    class IImporter
    {
    public:
        virtual ~IImporter() {}
    };
}