#include "core/Precomp.h"
#include "tinyxml2/tinyxml2.cpp"