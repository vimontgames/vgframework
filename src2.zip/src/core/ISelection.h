#pragma once

#include "core/Object/Object.h"

namespace vg::core
{
    class ISelection : public core::Object
    {
    public:
        virtual core::IObject *                 GetSelectedObject   () = 0;
        virtual core::vector<core::IObject *> & GetSelectedObjects  () = 0;
        
        virtual void                            SetSelectedObject   (core::IObject * _object) = 0;

        virtual void                            SetSelectedObjects  (const core::vector<core::IObject *> & _objects) = 0;
        virtual bool                            IsSelectedObject    (core::IObject * _object) = 0;
        
        virtual bool                            Add                 (core::IObject * _object) = 0;
        virtual bool                            Remove              (core::IObject * _object) = 0;

        virtual void                            Clear               () = 0;
    };
}