#include "core/Precomp.h"
#include "Model.h"

namespace vg::core
{
    //--------------------------------------------------------------------------------------
    Model::Model(const string & _name, IObject * _parent) :
        core::IModel(_name, _parent)
    {

    }
}