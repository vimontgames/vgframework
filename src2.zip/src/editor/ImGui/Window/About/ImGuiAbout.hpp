#include "ImguiAbout.h"

namespace vg::editor
{
    //--------------------------------------------------------------------------------------
    ImGuiAbout::ImGuiAbout() :
        ImGuiWindow(style::icon::About, "", "About", ImGuiWindow::None)
    {
    }

    //--------------------------------------------------------------------------------------
    void ImGuiAbout::DrawGUI()
    {
        if (IconBegin(style::icon::About, "About", &m_isVisible, ImGuiWindowFlags_NoDocking | ImGuiWindowFlags_NoCollapse))
        {
            Text("VG Framework");
            Text("");

            float columnWidth[3] = { 256, 128, 620 };

            Columns(3, "author", false);

            SetColumnWidth(0, columnWidth[0]);
            SetColumnWidth(1, columnWidth[1]);
            SetColumnWidth(2, columnWidth[2]);

            Text("GitHub");
            Text("Mastodon");
            Text("");

            NextColumn();
            NextColumn();

            textURL("github.com/vimontgames/vgframework", "https://github.com/vimontgames/vgframework");
            textURL("@benoitvimont@mastodon.gamedev.place", "https://mastodon.gamedev.place/@benoitvimont");
            Text("");

            Separator();

            Columns(1);
            Text("SDKs:");
            Text("");

            Columns(3, "SDK", false);

            SetColumnWidth(0, columnWidth[0]);
            SetColumnWidth(1, columnWidth[1]);
            SetColumnWidth(2, columnWidth[2]);

            // name                        
            Text("FBX SDK");
            Text("Vulkan SDK");
            Text("Windows 10 SDK");

            Text("");
            NextColumn();

            // version
            Text("2020.0.1");
            Text("1.3.261.1");
            Text("10.0.17763.0");

            Text("");
            NextColumn();
            // url
            textURL("www.autodesk.com/developer-network/platform-technologies/fbx-sdk-2020-0", "https://www.autodesk.com/developer-network/platform-technologies/fbx-sdk-2020-0");
            textURL("vulkan.lunarg.com/sdk/home", "https://sdk.lunarg.com/sdk/download/1.3.261.1/windows/VulkanSDK-1.3.261.1-Installer.exe");
            textURL("developer.microsoft.com/fr-fr/windows/downloads/sdk-archive", "https://developer.microsoft.com/fr-fr/windows/downloads/sdk-archive/");
            Text("");

            Separator();

            Columns(1);
            Text("3rd-parties:");
            Text("");

            Columns(3, "3rdparties", false);

            SetColumnWidth(0, columnWidth[0]);
            SetColumnWidth(1, columnWidth[1]);
            SetColumnWidth(2, columnWidth[2]);

            struct ThirdPartyInfo
            {
                const char * name;
                const char * version;
                const char * url;
            };

            ThirdPartyInfo thirdParties[] =
            {
                { "D3D12MemoryAllocator",   "",                 "https://github.com/GPUOpen-LibrariesAndSDKs/D3D12MemoryAllocator" },
                { "Dear ImGui",             "2a6d7b1",          "https://github.com/ocornut/imgui/tree/docking" },
                { "Dirent",                 "833b692",          "https://github.com/tronkko/dirent" },
                { "DirectXShaderCompiler",  "v1.7.2308",        "https://github.com/microsoft/DirectXShaderCompiler/releases/tag/v1.7.2308" },
                { "Font-Awesome",           "6.x ",             "https://github.com/FortAwesome/Font-Awesome/tree/6.x" },
                { "hlslpp",                 "3.3.1",            "https://github.com/redorav/hlslpp/releases/tag/3.3.1" },
                { "IconFontCppHeaders",     "90da802",          "https://github.com/juliettef/IconFontCppHeaders" },
                { "ImGui-Addons",           "ea0af59",          "https://github.com/gallickgunner/ImGui-Addons" },
                { "magic_enum",             "0.9.4",            "https://github.com/Neargye/magic_enum/releases/tag/v0.9.4" },
                { "optick",                 "1.3.1",            "https://github.com/bombomby/optick" },
                { "px_sched",               "",                 "https://github.com/pplux/px" },
                { "stb_image",              "",                 "https://github.com/nothings/stb" },
                { "tinyXML2",               "e45d9d1",          "https://github.com/leethomason/tinyxml2" },
                { "UFBX",                   "0.5.0-30f035b",    "https://github.com/ufbx/ufbx" },
                { "VulkanMemoryAllocator",  "",                 "https://github.com/GPUOpen-LibrariesAndSDKs/VulkanMemoryAllocator" },
                { "WinPixEventRuntime",     "1.0.200127001",    "https://www.nuget.org/packages/WinPixEventRuntime" },
            };


            for (uint i = 0; i < countof(thirdParties); ++i)
                Text(thirdParties[i].name);

            NextColumn();

            for (uint i = 0; i < countof(thirdParties); ++i)
                Text(thirdParties[i].version);

            NextColumn();

            for (uint i = 0; i < countof(thirdParties); ++i)
                textURL(thirdParties[i].url + strlen("https://"), thirdParties[i].url);

            Text("");

            Separator();

            Columns(1);
            Text("Special Thanks to SlavSquat, Bob, Guigui, Marcel, Hamilcar and the old guard :)");

            End();
        }
    }
}