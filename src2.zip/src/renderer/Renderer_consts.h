#pragma once

#include "gfx/Device/Device_consts.h"

namespace vg::renderer
{
    struct RendererCreationParams
    {
        gfx::DeviceParams device;
    };
}