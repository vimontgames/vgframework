#pragma once
#define IMGUI_DEFINE_MATH_OPERATORS
#include "../extern/imgui/imgui.h"