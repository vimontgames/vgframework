#include "renderer/Precomp.h"
#include "PickingManager.h"
#include "core/IInput.h"
#include "core/ISelection.h"
#include "core/IInstance.h"
#include "core/IComponent.h"
#include "core/IGameObject.h"
#include "gfx/IView.h"
#include "Shaders/system/toolmode.hlsl.h"

using namespace vg::core;

namespace vg::renderer
{
    //--------------------------------------------------------------------------------------
    PickingManager::PickingManager()
    {
        m_pickingID.push_back(nullptr);
    }
    
    //--------------------------------------------------------------------------------------
    PickingManager::~PickingManager()
    {
    
    }

    //--------------------------------------------------------------------------------------
    PickingID PickingManager::GetPickingID(IObject * _object)
    {
        PickingID id = -1;

        // Lookup available slots
        for (uint i = 1; i < m_pickingID.size(); ++i)
        {
            auto & slot = m_pickingID[i];
            if (slot == nullptr)
            {
                slot = _object;
                id = i;
                return id;
            }
        }

        // Alloc new slot
        id = (PickingID)m_pickingID.size();
        m_pickingID.push_back(_object);
        return id;
    }

    //--------------------------------------------------------------------------------------
    void PickingManager::ReleasePickingID(PickingID _id)
    {
        VG_ASSERT(0 != _id);
        VG_ASSERT(_id < m_pickingID.size());
        m_pickingID[_id] = nullptr;
    }

    //--------------------------------------------------------------------------------------
    void PickingManager::Update(const gfx::IView * _view)
    {
        const PickingData & pickingData = _view->GetPickingData();
        const uint4 id = pickingData.m_id;
        const float4 pos = pickingData.m_pos;

        const auto mousePos = _view->GetRelativeMousePos();
        const auto viewSize = _view->GetSize();

        if (all(mousePos.xy >= 0) && all(mousePos.xy < viewSize.xy))
        {
            auto input = Kernel::getInput();
            const bool ctrl = input->IsKeyPressed(Key::LCONTROL) || input->IsKeyPressed(Key::LCONTROL);

            if (input->IsMouseButtonJustPressed(MouseButton::Left))
            {
                auto selection = Kernel::getSelection();

                if (0 != id.x && id.x < m_pickingID.size())
                {
                    IObject * object = m_pickingID[id.x];
                    if (nullptr != object)
                    {
                        IComponent * component = dynamic_cast<IComponent *>(object);

                        if (nullptr != component)
                        {
                            IObject * parent = component->getParent();
                            IGameObject * go = dynamic_cast<IGameObject *>(parent);
                            if (nullptr != go)
                            {
                                if (ctrl)
                                {
                                    if (selection->IsSelectedObject(go))
                                        selection->Remove(go);
                                    else
                                        selection->Add(go);
                                }
                                else
                                {
                                    selection->Clear();
                                    selection->Add(go);
                                }
                            }
                        }
                    }
                }
                else
                {
                    if (!ctrl)
                        selection->Clear();
                }
            }
        }
    }
}